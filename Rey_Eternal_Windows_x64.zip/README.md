# Rey Eternal · Primera entrega jugable

Extraé el ZIP y ejecutá **Rey_Eternal.exe**. El lanzador abre el navegador predeterminado y sirve los recursos incluidos por la dirección local 127.0.0.1, puerto 41873. Si la ventana del navegador no aparece automáticamente, escribí la dirección que muestra el lanzador. Mantené abierta la consola mientras jugás. Requiere Windows de 64 bits y un navegador de escritorio con WebGL (Edge, Chrome o Firefox). La partida funciona sin conexión.

## Jugar

Elegí Nueva partida. Seguí el rombo dorado y acercate a menos de 3,4 m para interactuar. El encapuchado se arrastra hasta la orilla en dos interacciones. En combate, acercate a un enemigo y usá la espada o Lanzallamas. Contra grupos, el fuego alcanza enemigos próximos al blanco. En el tránsito espectral caminá hasta el punto del sendero donde querés volver. Los vivos siguen la defensa de la puerta. 

| Control | Acción |
|---|---|
| WASD, ratón | Caminar y orientar la cámara. Hacé clic en la escena para capturar el puntero. |
| Flechas izquierda y derecha | Girar sin capturar el puntero. |
| Espacio, Mayús izquierda | Saltar, correr. |
| Clic izquierdo, derecho, Q | Espada, mantener bloqueo, Lanzallamas. |
| E | Rescatar, reunir, activar el objetivo próximo o recoger el hallazgo. |
| Tab | Vista elevada dentro de Alta Corona. En la primera tarea, junto a la granja, pulsá E para organizar el turno. |
| H, I | Consultar habitantes y asignar oficios disponibles, consultar inventario. Desde H podés ordenar la segunda cocina y asignar un constructor. |
| M | Elegir una ruta en el tablón tras el pacto del Junco. |
| F5, P | Guardar en la única ranura, pausar y volver al menú para cargar. |

El guardado se conserva en el almacenamiento local del perfil del navegador, bajo el origen http://127.0.0.1:41873. Para continuar usá el mismo navegador y perfil. El modo privado y el borrado de datos del sitio pueden eliminar la partida. F5 también guarda durante la caída y el tránsito.

## Alcance de esta versión

El prólogo, tránsito, fundación, cosecha, exploración del Vado y primera defensa forman el recorrido inicial. Continúa con la mina, la escolta del Junco, el tablón regional, encuentros de jefes, tres oleadas con Vardek y una escena de epílogo. Las expediciones posteriores reutilizan la galería, la compuerta y la arena. Los premios aparecen en el inventario, con Lanzallamas como hechizo operativo. La defensa y las obras son versiones iniciales. La población tiene edad, hogar, oficio, consumo y mortalidad. El calendario corre desde la fundación.

Quedan por desarrollar los mapas y conductas particulares de las diez mazmorras, los objetivos completos de campaña y sus consecuencias, las 18 secundarias, caravanas, expediciones autónomas, simulación familiar y formación, árboles completos de magia, armas y construcciones, accesibilidad, guardados múltiples, sonido y animación finales, y calibración del rendimiento. El GDD completo se incluye como referencia en el proyecto fuente.

## Desarrollar y compilar

Los recursos de Three.js 0.160.0 están incluidos. Desde la raíz, con Python 3 ejecutá `python -m http.server 41873 --bind 127.0.0.1 --directory juego` y abrí el sitio local. Con Node 18+ ejecutá `node pruebas/recorrido.mjs`. La prueba de interfaz necesita Python, Playwright, Chromium en /usr/bin/chromium y el servidor activo: `python pruebas/interfaz.py`.

Con Go instalado, en Linux o macOS ejecutá `GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -o Rey_Eternal.exe .`. En Windows de 64 bits ejecutá `go build -trimpath -o Rey_Eternal.exe .`. El lanzador incluye todo el directorio juego mediante go:embed. Para actualizar el paquete recompilá después de cualquier cambio.

## Reemplazar modelos

Unidades en metros, eje Y vertical, frente local +Z, origen en el suelo entre los pies. En juego/modelos.js, persona(tipo) crea a Loftart, el encapuchado, Sair, Iria, habitantes y espectros. Altura adulta aproximada 2,1 m. La raíz contiene piernas y brazos en userData. La espada se monta en brazos[1]; para un esqueleto nuevo, colocá un anclaje en la mano derecha con la hoja hacia +Z. bestia() genera enemigos cuadrúpedos; vardek() genera al jefe final. casa(i,w,d) recibe semiancho y semiprofundidad en metros y sitúa la entrada en -Z. El castillo usa el índice 4. El terreno, río, árboles, portón y decoración se colocan en juego/vista.js. Sustituí sus mallas conservando las transformaciones de la raíz.

animar() reconoce reposo, caminar, atacar, lanzar, caida e interaccion. variante() controla la apariencia espectral; la salida recupera la apariencia ordinaria. Al importar un personaje, adaptá esos nombres a sus clips y su material. juego/mundo.js guarda el controlador, los volúmenes sólidos, las posiciones de interacción y la máquina de estados de misión. Las mallas no determinan la colisión ni el guardado. juego/ciudad.js resuelve oficios y producción, y juego/regiones.js los destinos y el asedio.

## Validación y licencias

Se probó el motor de reglas con Node y la interfaz renderizada en Chromium sobre Linux. La prueba de reglas posiciona al personaje en los objetivos para recorrer el guion y simula combate y tiempo. La de navegador camina en la escena del río, interactúa, guarda y carga; prepara el encuentro espectral mediante la API de misión y comprueba la reaparición tras recargar la página. Falta probar en Windows 10/11 y medir FPS y memoria en la PC objetivo de 4 GB.

Geometría, composición y lógica creadas para este proyecto. Three.js se distribuye según juego/LICENSE-three.txt y el runtime de Go según LICENSE-Go.txt. Ambos avisos acompañan el ejecutable.
